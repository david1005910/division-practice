#!/bin/bash

echo "========================================"
echo "🚀 RAG AI 앱 설치 스크립트"
echo "========================================"
echo ""

# 색상 정의
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# 함수: 상태 출력
print_status() {
    echo -e "${GREEN}[✓]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[!]${NC} $1"
}

print_error() {
    echo -e "${RED}[✗]${NC} $1"
}

# Termux 패키지 업데이트
echo "📦 패키지 업데이트 중..."
pkg update -y && pkg upgrade -y
print_status "패키지 업데이트 완료"

# 필수 패키지 설치
echo ""
echo "📦 필수 패키지 설치 중..."
pkg install -y python python-pip git clang libxml2 libxslt
print_status "기본 패키지 설치 완료"

# pip 업그레이드
echo ""
echo "🐍 pip 업그레이드 중..."
pip install --upgrade pip
print_status "pip 업그레이드 완료"

# Python 패키지 설치
echo ""
echo "📚 Python 라이브러리 설치 중..."
echo "   (시간이 좀 걸릴 수 있습니다...)"

# numpy 설치 (특별 처리 필요)
echo "   - numpy 설치 중..."
pip install numpy==1.26.2

# scikit-learn 설치
echo "   - scikit-learn 설치 중..."
pip install scikit-learn==1.3.2

# 나머지 패키지 설치
echo "   - 기타 패키지 설치 중..."
pip install flask flask-cors requests PyPDF2 python-docx werkzeug

print_status "Python 라이브러리 설치 완료"

# 디렉토리 생성
echo ""
echo "📁 디렉토리 생성 중..."
mkdir -p ~/rag-app/static
mkdir -p ~/rag-app/uploads
mkdir -p ~/rag-app/vector_db
print_status "디렉토리 생성 완료"

# 앱 파일이 현재 디렉토리에 있으면 복사
if [ -f "app.py" ]; then
    cp app.py ~/rag-app/
    print_status "app.py 복사 완료"
fi

if [ -f "static/index.html" ]; then
    cp static/index.html ~/rag-app/static/
    print_status "index.html 복사 완료"
fi

echo ""
echo "========================================"
echo -e "${GREEN}✅ 설치 완료!${NC}"
echo "========================================"
echo ""
echo "📋 실행 방법:"
echo ""
echo "   1. 환경변수 설정 (Mac IP 주소로 변경하세요):"
echo "      export OLLAMA_HOST=http://192.168.129.15:11434"
echo ""
echo "   2. 앱 실행:"
echo "      cd ~/rag-app"
echo "      python app.py"
echo ""
echo "   3. 브라우저에서 접속:"
echo "      http://localhost:5001"
echo ""
echo "========================================"
