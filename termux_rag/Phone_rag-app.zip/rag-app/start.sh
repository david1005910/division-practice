#!/bin/bash

# RAG 앱 실행 스크립트

# Ollama 서버 주소 설정 (필요시 수정)
export OLLAMA_HOST="${OLLAMA_HOST:-http://192.168.129.15:11434}"

echo "========================================"
echo "🤖 RAG AI 앱 시작"
echo "========================================"
echo ""
echo "📡 Ollama 서버: $OLLAMA_HOST"
echo "🌐 웹 주소: http://localhost:5001"
echo ""
echo "종료하려면 Ctrl+C를 누르세요"
echo "========================================"
echo ""

cd ~/rag-app
python app.py
