# 🤖 RAG AI 어시스턴트

Termux에서 실행하는 RAG(Retrieval-Augmented Generation) 웹앱입니다.

## ✨ 기능

- 📚 **문서 업로드**: PDF, TXT, DOCX, MD 파일 지원
- 💬 **RAG 대화**: 업로드한 문서 내용 기반으로 AI와 대화
- 🌐 **웹 검색**: DuckDuckGo를 통한 실시간 웹 검색
- 🎤 **음성 입력**: 마이크로 질문하기
- 🔊 **음성 출력**: AI 답변을 음성으로 듣기
- ⚙️ **설정**: Ollama 서버 주소 및 모델 변경

## 📱 설치 방법

### 1단계: 파일 다운로드

Termux에서 아래 명령어 실행:

```bash
# 홈 디렉토리로 이동
cd ~

# rag-app 폴더 생성
mkdir -p rag-app/static

# 파일 다운로드 (또는 직접 복사)
# app.py와 static/index.html 파일을 rag-app 폴더에 넣으세요
```

### 2단계: 설치 스크립트 실행

```bash
cd ~/rag-app
chmod +x install.sh
./install.sh
```

또는 수동 설치:

```bash
# 패키지 설치
pkg update && pkg upgrade
pkg install python python-pip

# Python 라이브러리 설치
pip install flask flask-cors requests PyPDF2 python-docx numpy scikit-learn
```

## 🚀 실행 방법

### Mac에서 (Ollama 서버)

```bash
# 기존 Ollama 종료
pkill -f ollama

# 외부 접속 허용하여 실행
OLLAMA_HOST=0.0.0.0:11434 ollama serve
```

### Termux에서 (RAG 앱)

```bash
# 환경변수 설정 (Mac의 IP 주소로 변경)
export OLLAMA_HOST=http://192.168.129.15:11434

# 앱 실행
cd ~/rag-app
python app.py
```

또는 간편 실행:

```bash
chmod +x start.sh
./start.sh
```

### 브라우저에서 접속

휴대폰 브라우저를 열고:
```
http://localhost:5001
```

## 📖 사용 방법

### 문서 업로드
1. **문서** 탭 클릭
2. 파일을 드래그하거나 클릭하여 업로드
3. PDF, TXT, DOCX, MD 파일 지원

### AI와 대화
1. **채팅** 탭에서 메시지 입력
2. **RAG** 버튼: 문서 기반 답변 (켜기/끄기)
3. **웹검색** 버튼: 웹 검색 포함 (켜기/끄기)
4. **음성출력** 버튼: AI 답변을 음성으로 듣기

### 음성 입력
1. 🎤 마이크 버튼 클릭
2. 말하기
3. 자동으로 텍스트 변환

### 설정 변경
1. **설정** 탭 클릭
2. Ollama 서버 주소 입력
3. 모델 선택
4. **설정 저장** 클릭

## 🔧 문제 해결

### "Ollama 서버에 연결할 수 없습니다"

1. Mac에서 Ollama가 실행 중인지 확인
2. Mac의 IP 주소가 정확한지 확인
3. Mac에서 `OLLAMA_HOST=0.0.0.0:11434 ollama serve`로 실행했는지 확인
4. 같은 WiFi 네트워크인지 확인

### 음성 인식이 안 됨

- 브라우저에서 마이크 권한을 허용했는지 확인
- Chrome이나 Edge 브라우저 사용 권장

### 문서 업로드 실패

- 파일 크기가 너무 크지 않은지 확인
- 지원 형식: PDF, TXT, DOCX, MD

## 📁 파일 구조

```
rag-app/
├── app.py              # 메인 서버
├── static/
│   └── index.html      # 웹 인터페이스
├── uploads/            # 업로드된 문서
├── vector_db/          # 벡터 DB 저장소
├── requirements.txt    # Python 의존성
├── install.sh          # 설치 스크립트
├── start.sh            # 실행 스크립트
└── README.md           # 이 파일
```

## 🛠️ 기술 스택

- **Backend**: Flask (Python)
- **Frontend**: Vanilla JS + CSS
- **AI**: Ollama (gemma3:4b)
- **벡터 검색**: TF-IDF + Cosine Similarity
- **웹 검색**: DuckDuckGo API
- **음성**: Web Speech API

---

Made with ❤️ for Termux
