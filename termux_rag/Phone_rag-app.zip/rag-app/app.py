"""
RAG (Retrieval-Augmented Generation) 웹앱
- 문서 업로드 (PDF, TXT, DOCX)
- 문서 기반 AI 대화
- Ollama 연결
- 음성 입력/출력
- 웹 검색
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from werkzeug.utils import secure_filename
import os
import json
import requests
from datetime import datetime
import hashlib

# 문서 처리
import PyPDF2
from docx import Document

# 벡터 DB (간단한 구현)
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import pickle

app = Flask(__name__, static_folder='static')
CORS(app)

# 설정
UPLOAD_FOLDER = 'uploads'
VECTOR_DB_PATH = 'vector_db'
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'docx', 'md'}

# Ollama 설정 (환경변수로 변경 가능)
OLLAMA_HOST = os.environ.get('OLLAMA_HOST', 'http://192.168.129.15:11434')
DEFAULT_MODEL = os.environ.get('OLLAMA_MODEL', 'gemma3:4b')

# 디렉토리 생성
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(VECTOR_DB_PATH, exist_ok=True)

# 전역 변수
documents = {}  # {doc_id: {filename, content, chunks}}
vectorizer = TfidfVectorizer(max_features=5000)
document_vectors = None
all_chunks = []


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def extract_text_from_pdf(file_path):
    """PDF에서 텍스트 추출"""
    text = ""
    try:
        with open(file_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            for page in reader.pages:
                text += page.extract_text() or ""
    except Exception as e:
        print(f"PDF 추출 오류: {e}")
    return text


def extract_text_from_docx(file_path):
    """DOCX에서 텍스트 추출"""
    text = ""
    try:
        doc = Document(file_path)
        for para in doc.paragraphs:
            text += para.text + "\n"
    except Exception as e:
        print(f"DOCX 추출 오류: {e}")
    return text


def extract_text_from_txt(file_path):
    """TXT에서 텍스트 추출"""
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            return file.read()
    except:
        with open(file_path, 'r', encoding='latin-1') as file:
            return file.read()


def chunk_text(text, chunk_size=500, overlap=50):
    """텍스트를 청크로 분할"""
    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        chunk = text[start:end]
        if chunk.strip():
            chunks.append(chunk.strip())
        start = end - overlap
    return chunks


def update_vector_db():
    """벡터 DB 업데이트"""
    global document_vectors, all_chunks, vectorizer
    
    all_chunks = []
    chunk_metadata = []
    
    for doc_id, doc_info in documents.items():
        for i, chunk in enumerate(doc_info['chunks']):
            all_chunks.append(chunk)
            chunk_metadata.append({
                'doc_id': doc_id,
                'filename': doc_info['filename'],
                'chunk_index': i
            })
    
    if all_chunks:
        vectorizer = TfidfVectorizer(max_features=5000)
        document_vectors = vectorizer.fit_transform(all_chunks)
        
        # 저장
        with open(os.path.join(VECTOR_DB_PATH, 'vectors.pkl'), 'wb') as f:
            pickle.dump({
                'vectors': document_vectors,
                'chunks': all_chunks,
                'metadata': chunk_metadata,
                'vectorizer': vectorizer
            }, f)
    
    return len(all_chunks)


def search_documents(query, top_k=3):
    """문서에서 관련 청크 검색"""
    global document_vectors, all_chunks, vectorizer
    
    if not all_chunks or document_vectors is None:
        return []
    
    query_vector = vectorizer.transform([query])
    similarities = cosine_similarity(query_vector, document_vectors)[0]
    
    top_indices = np.argsort(similarities)[-top_k:][::-1]
    
    results = []
    for idx in top_indices:
        if similarities[idx] > 0.1:  # 최소 유사도 임계값
            results.append({
                'chunk': all_chunks[idx],
                'score': float(similarities[idx])
            })
    
    return results


def call_ollama(prompt, model=None, system_prompt=None):
    """Ollama API 호출"""
    model = model or DEFAULT_MODEL
    
    try:
        payload = {
            'model': model,
            'prompt': prompt,
            'stream': False
        }
        
        if system_prompt:
            payload['system'] = system_prompt
        
        response = requests.post(
            f'{OLLAMA_HOST}/api/generate',
            json=payload,
            timeout=120
        )
        
        if response.status_code == 200:
            return response.json().get('response', '')
        else:
            return f"Ollama 오류: {response.status_code}"
    
    except requests.exceptions.ConnectionError:
        return "❌ Ollama 서버에 연결할 수 없습니다. 서버가 실행 중인지 확인하세요."
    except requests.exceptions.Timeout:
        return "⏰ 응답 시간이 초과되었습니다."
    except Exception as e:
        return f"오류: {str(e)}"


def web_search(query):
    """DuckDuckGo를 이용한 웹 검색 (API 없이)"""
    try:
        # DuckDuckGo Instant Answer API (무료)
        response = requests.get(
            'https://api.duckduckgo.com/',
            params={
                'q': query,
                'format': 'json',
                'no_html': 1,
                'skip_disambig': 1
            },
            timeout=10
        )
        
        if response.status_code == 200:
            data = response.json()
            results = []
            
            # Abstract
            if data.get('Abstract'):
                results.append({
                    'title': data.get('Heading', '검색 결과'),
                    'snippet': data.get('Abstract'),
                    'url': data.get('AbstractURL', '')
                })
            
            # Related Topics
            for topic in data.get('RelatedTopics', [])[:5]:
                if isinstance(topic, dict) and topic.get('Text'):
                    results.append({
                        'title': topic.get('Text', '')[:50],
                        'snippet': topic.get('Text', ''),
                        'url': topic.get('FirstURL', '')
                    })
            
            return results if results else [{'title': '결과 없음', 'snippet': '검색 결과를 찾을 수 없습니다.', 'url': ''}]
        
        return [{'title': '검색 실패', 'snippet': '검색 중 오류가 발생했습니다.', 'url': ''}]
    
    except Exception as e:
        return [{'title': '검색 오류', 'snippet': str(e), 'url': ''}]


# ============ API 라우트 ============

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')


@app.route('/api/upload', methods=['POST'])
def upload_file():
    """파일 업로드"""
    if 'file' not in request.files:
        return jsonify({'error': '파일이 없습니다'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': '파일이 선택되지 않았습니다'}), 400
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        unique_filename = f"{timestamp}_{filename}"
        file_path = os.path.join(UPLOAD_FOLDER, unique_filename)
        file.save(file_path)
        
        # 텍스트 추출
        ext = filename.rsplit('.', 1)[1].lower()
        if ext == 'pdf':
            content = extract_text_from_pdf(file_path)
        elif ext == 'docx':
            content = extract_text_from_docx(file_path)
        else:
            content = extract_text_from_txt(file_path)
        
        # 청크 분할
        chunks = chunk_text(content)
        
        # 문서 저장
        doc_id = hashlib.md5(unique_filename.encode()).hexdigest()[:8]
        documents[doc_id] = {
            'filename': filename,
            'content': content,
            'chunks': chunks,
            'uploaded_at': timestamp
        }
        
        # 벡터 DB 업데이트
        total_chunks = update_vector_db()
        
        return jsonify({
            'success': True,
            'doc_id': doc_id,
            'filename': filename,
            'chunks': len(chunks),
            'total_chunks': total_chunks
        })
    
    return jsonify({'error': '허용되지 않는 파일 형식입니다'}), 400


@app.route('/api/documents', methods=['GET'])
def get_documents():
    """업로드된 문서 목록"""
    doc_list = []
    for doc_id, doc_info in documents.items():
        doc_list.append({
            'id': doc_id,
            'filename': doc_info['filename'],
            'chunks': len(doc_info['chunks']),
            'uploaded_at': doc_info['uploaded_at']
        })
    return jsonify({'documents': doc_list})


@app.route('/api/documents/<doc_id>', methods=['DELETE'])
def delete_document(doc_id):
    """문서 삭제"""
    if doc_id in documents:
        del documents[doc_id]
        update_vector_db()
        return jsonify({'success': True})
    return jsonify({'error': '문서를 찾을 수 없습니다'}), 404


@app.route('/api/chat', methods=['POST'])
def chat():
    """RAG 기반 채팅"""
    data = request.json
    query = data.get('message', '')
    use_rag = data.get('use_rag', True)
    use_web = data.get('use_web', False)
    model = data.get('model', DEFAULT_MODEL)
    
    if not query:
        return jsonify({'error': '메시지가 없습니다'}), 400
    
    context_parts = []
    sources = []
    
    # RAG 검색
    if use_rag and all_chunks:
        rag_results = search_documents(query, top_k=3)
        if rag_results:
            context_parts.append("📚 **문서에서 찾은 관련 내용:**")
            for i, result in enumerate(rag_results, 1):
                context_parts.append(f"\n[문서 {i}] (유사도: {result['score']:.2f})\n{result['chunk']}")
                sources.append({'type': 'document', 'content': result['chunk'][:100] + '...'})
    
    # 웹 검색
    if use_web:
        web_results = web_search(query)
        if web_results and web_results[0]['title'] != '결과 없음':
            context_parts.append("\n\n🌐 **웹 검색 결과:**")
            for result in web_results[:3]:
                context_parts.append(f"\n- {result['title']}: {result['snippet']}")
                sources.append({'type': 'web', 'title': result['title'], 'url': result['url']})
    
    # 프롬프트 구성
    if context_parts:
        full_prompt = f"""다음 정보를 참고하여 질문에 답변해주세요.

{''.join(context_parts)}

---
사용자 질문: {query}

위 정보를 바탕으로 친절하고 정확하게 답변해주세요. 정보가 부족하면 솔직하게 말해주세요."""
    else:
        full_prompt = query
    
    # Ollama 호출
    system_prompt = "당신은 친절하고 도움이 되는 AI 어시스턴트입니다. 한국어로 답변해주세요."
    response = call_ollama(full_prompt, model=model, system_prompt=system_prompt)
    
    return jsonify({
        'response': response,
        'sources': sources,
        'used_rag': use_rag and bool(all_chunks),
        'used_web': use_web
    })


@app.route('/api/web-search', methods=['POST'])
def api_web_search():
    """웹 검색 API"""
    data = request.json
    query = data.get('query', '')
    
    if not query:
        return jsonify({'error': '검색어가 없습니다'}), 400
    
    results = web_search(query)
    return jsonify({'results': results})


@app.route('/api/ollama/status', methods=['GET'])
def ollama_status():
    """Ollama 연결 상태 확인"""
    try:
        response = requests.get(f'{OLLAMA_HOST}', timeout=5)
        if response.status_code == 200:
            # 모델 목록 가져오기
            models_response = requests.get(f'{OLLAMA_HOST}/api/tags', timeout=5)
            models = []
            if models_response.status_code == 200:
                models_data = models_response.json()
                models = [m['name'] for m in models_data.get('models', [])]
            
            return jsonify({
                'status': 'connected',
                'host': OLLAMA_HOST,
                'models': models,
                'default_model': DEFAULT_MODEL
            })
    except:
        pass
    
    return jsonify({
        'status': 'disconnected',
        'host': OLLAMA_HOST,
        'models': [],
        'default_model': DEFAULT_MODEL
    })


@app.route('/api/settings', methods=['GET', 'POST'])
def settings():
    """설정 조회/변경"""
    global OLLAMA_HOST, DEFAULT_MODEL
    
    if request.method == 'POST':
        data = request.json
        if 'ollama_host' in data:
            OLLAMA_HOST = data['ollama_host']
        if 'default_model' in data:
            DEFAULT_MODEL = data['default_model']
        
        return jsonify({'success': True})
    
    return jsonify({
        'ollama_host': OLLAMA_HOST,
        'default_model': DEFAULT_MODEL
    })


if __name__ == '__main__':
    print("=" * 50)
    print("🚀 RAG 웹앱 시작!")
    print(f"📡 Ollama 서버: {OLLAMA_HOST}")
    print(f"🤖 기본 모델: {DEFAULT_MODEL}")
    print("=" * 50)
    print("\n브라우저에서 http://localhost:5001 접속하세요\n")
    
    app.run(host='0.0.0.0', port=5001, debug=True)
