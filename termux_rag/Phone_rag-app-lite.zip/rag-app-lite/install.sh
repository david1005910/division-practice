#!/bin/bash

echo "========================================"
echo "🚀 RAG AI 앱 설치 (경량 버전)"
echo "   - scikit-learn 불필요!"
echo "========================================"
echo ""

# 패키지 업데이트
echo "📦 패키지 업데이트 중..."
pkg update -y

# 필수 패키지 설치
echo ""
echo "📦 필수 패키지 설치 중..."
pkg install -y python

# pip 업그레이드
echo ""
echo "🐍 pip 업그레이드..."
pip install --upgrade pip

# Python 패키지 설치 (scikit-learn 제외!)
echo ""
echo "📚 Python 라이브러리 설치 중..."
pip install flask flask-cors requests PyPDF2 python-docx

echo ""
echo "========================================"
echo "✅ 설치 완료!"
echo "========================================"
echo ""
echo "실행 방법:"
echo ""
echo "  1. export OLLAMA_HOST=http://YOUR_MAC_IP:11434"
echo "  2. python app.py"
echo "  3. 브라우저에서 http://localhost:5001"
echo ""
