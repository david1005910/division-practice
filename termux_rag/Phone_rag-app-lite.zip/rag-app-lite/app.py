"""
RAG (Retrieval-Augmented Generation) 웹앱 - Termux 경량 버전
- scikit-learn 없이 작동
- 간단한 키워드 매칭 검색 사용
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from werkzeug.utils import secure_filename
import os
import json
import requests
from datetime import datetime
import hashlib
import re
from collections import Counter

# 문서 처리
import PyPDF2
from docx import Document

app = Flask(__name__, static_folder='static')
CORS(app)

# 설정
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'docx', 'md'}

# Ollama 설정
OLLAMA_HOST = os.environ.get('OLLAMA_HOST', 'http://192.168.129.15:11434')
DEFAULT_MODEL = os.environ.get('OLLAMA_MODEL', 'gemma3:4b')

# 디렉토리 생성
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# 전역 변수
documents = {}  # {doc_id: {filename, content, chunks}}
all_chunks = []  # [(chunk_text, doc_id, filename), ...]


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def extract_text_from_pdf(file_path):
    """PDF에서 텍스트 추출"""
    text = ""
    try:
        with open(file_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            for page in reader.pages:
                text += page.extract_text() or ""
    except Exception as e:
        print(f"PDF 추출 오류: {e}")
    return text


def extract_text_from_docx(file_path):
    """DOCX에서 텍스트 추출"""
    text = ""
    try:
        doc = Document(file_path)
        for para in doc.paragraphs:
            text += para.text + "\n"
    except Exception as e:
        print(f"DOCX 추출 오류: {e}")
    return text


def extract_text_from_txt(file_path):
    """TXT에서 텍스트 추출"""
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            return file.read()
    except:
        try:
            with open(file_path, 'r', encoding='latin-1') as file:
                return file.read()
        except:
            return ""


def chunk_text(text, chunk_size=500, overlap=50):
    """텍스트를 청크로 분할"""
    chunks = []
    start = 0
    text = text.strip()
    while start < len(text):
        end = start + chunk_size
        chunk = text[start:end]
        if chunk.strip():
            chunks.append(chunk.strip())
        start = end - overlap
    return chunks


def tokenize(text):
    """간단한 토큰화 (한국어/영어 지원)"""
    # 소문자 변환 및 특수문자 제거
    text = text.lower()
    # 한글, 영문, 숫자만 추출
    tokens = re.findall(r'[가-힣]+|[a-z]+|[0-9]+', text)
    return tokens


def simple_search(query, top_k=3):
    """간단한 키워드 기반 검색 (TF-IDF 대체)"""
    if not all_chunks:
        return []
    
    query_tokens = set(tokenize(query))
    if not query_tokens:
        return []
    
    results = []
    
    for chunk_text, doc_id, filename in all_chunks:
        chunk_tokens = tokenize(chunk_text)
        chunk_token_set = set(chunk_tokens)
        
        # 매칭되는 토큰 수 계산
        matches = query_tokens & chunk_token_set
        
        if matches:
            # 간단한 점수 계산: 매칭 토큰 수 / 쿼리 토큰 수
            score = len(matches) / len(query_tokens)
            
            # 매칭 토큰이 청크에서 얼마나 자주 나오는지도 고려
            chunk_counter = Counter(chunk_tokens)
            freq_bonus = sum(chunk_counter[m] for m in matches) / (len(chunk_tokens) + 1)
            
            final_score = score + (freq_bonus * 0.5)
            
            results.append({
                'chunk': chunk_text,
                'score': final_score,
                'doc_id': doc_id,
                'filename': filename
            })
    
    # 점수순 정렬
    results.sort(key=lambda x: x['score'], reverse=True)
    
    return results[:top_k]


def update_chunks():
    """청크 목록 업데이트"""
    global all_chunks
    all_chunks = []
    
    for doc_id, doc_info in documents.items():
        for chunk in doc_info['chunks']:
            all_chunks.append((chunk, doc_id, doc_info['filename']))
    
    return len(all_chunks)


def call_ollama(prompt, model=None, system_prompt=None):
    """Ollama API 호출"""
    model = model or DEFAULT_MODEL
    
    try:
        payload = {
            'model': model,
            'prompt': prompt,
            'stream': False
        }
        
        if system_prompt:
            payload['system'] = system_prompt
        
        response = requests.post(
            f'{OLLAMA_HOST}/api/generate',
            json=payload,
            timeout=120
        )
        
        if response.status_code == 200:
            return response.json().get('response', '')
        else:
            return f"Ollama 오류: {response.status_code}"
    
    except requests.exceptions.ConnectionError:
        return "❌ Ollama 서버에 연결할 수 없습니다. 서버가 실행 중인지 확인하세요."
    except requests.exceptions.Timeout:
        return "⏰ 응답 시간이 초과되었습니다."
    except Exception as e:
        return f"오류: {str(e)}"


def web_search(query):
    """DuckDuckGo 웹 검색"""
    try:
        response = requests.get(
            'https://api.duckduckgo.com/',
            params={
                'q': query,
                'format': 'json',
                'no_html': 1,
                'skip_disambig': 1
            },
            timeout=10
        )
        
        if response.status_code == 200:
            data = response.json()
            results = []
            
            if data.get('Abstract'):
                results.append({
                    'title': data.get('Heading', '검색 결과'),
                    'snippet': data.get('Abstract'),
                    'url': data.get('AbstractURL', '')
                })
            
            for topic in data.get('RelatedTopics', [])[:5]:
                if isinstance(topic, dict) and topic.get('Text'):
                    results.append({
                        'title': topic.get('Text', '')[:50],
                        'snippet': topic.get('Text', ''),
                        'url': topic.get('FirstURL', '')
                    })
            
            return results if results else [{'title': '결과 없음', 'snippet': '검색 결과를 찾을 수 없습니다.', 'url': ''}]
        
        return [{'title': '검색 실패', 'snippet': '검색 중 오류가 발생했습니다.', 'url': ''}]
    
    except Exception as e:
        return [{'title': '검색 오류', 'snippet': str(e), 'url': ''}]


# ============ API 라우트 ============

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')


@app.route('/api/upload', methods=['POST'])
def upload_file():
    """파일 업로드"""
    if 'file' not in request.files:
        return jsonify({'error': '파일이 없습니다'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': '파일이 선택되지 않았습니다'}), 400
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        # 한글 파일명 지원
        if not filename or filename == '':
            filename = file.filename
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        unique_filename = f"{timestamp}_{filename}"
        file_path = os.path.join(UPLOAD_FOLDER, unique_filename)
        file.save(file_path)
        
        # 텍스트 추출
        ext = filename.rsplit('.', 1)[1].lower() if '.' in filename else 'txt'
        if ext == 'pdf':
            content = extract_text_from_pdf(file_path)
        elif ext == 'docx':
            content = extract_text_from_docx(file_path)
        else:
            content = extract_text_from_txt(file_path)
        
        # 청크 분할
        chunks = chunk_text(content)
        
        # 문서 저장
        doc_id = hashlib.md5(unique_filename.encode()).hexdigest()[:8]
        documents[doc_id] = {
            'filename': filename,
            'content': content,
            'chunks': chunks,
            'uploaded_at': timestamp
        }
        
        # 청크 목록 업데이트
        total_chunks = update_chunks()
        
        return jsonify({
            'success': True,
            'doc_id': doc_id,
            'filename': filename,
            'chunks': len(chunks),
            'total_chunks': total_chunks
        })
    
    return jsonify({'error': '허용되지 않는 파일 형식입니다'}), 400


@app.route('/api/documents', methods=['GET'])
def get_documents():
    """업로드된 문서 목록"""
    doc_list = []
    for doc_id, doc_info in documents.items():
        doc_list.append({
            'id': doc_id,
            'filename': doc_info['filename'],
            'chunks': len(doc_info['chunks']),
            'uploaded_at': doc_info['uploaded_at']
        })
    return jsonify({'documents': doc_list})


@app.route('/api/documents/<doc_id>', methods=['DELETE'])
def delete_document(doc_id):
    """문서 삭제"""
    if doc_id in documents:
        del documents[doc_id]
        update_chunks()
        return jsonify({'success': True})
    return jsonify({'error': '문서를 찾을 수 없습니다'}), 404


@app.route('/api/chat', methods=['POST'])
def chat():
    """RAG 기반 채팅"""
    data = request.json
    query = data.get('message', '')
    use_rag = data.get('use_rag', True)
    use_web = data.get('use_web', False)
    model = data.get('model', DEFAULT_MODEL)
    
    if not query:
        return jsonify({'error': '메시지가 없습니다'}), 400
    
    context_parts = []
    sources = []
    
    # RAG 검색
    if use_rag and all_chunks:
        rag_results = simple_search(query, top_k=3)
        if rag_results:
            context_parts.append("📚 **문서에서 찾은 관련 내용:**")
            for i, result in enumerate(rag_results, 1):
                context_parts.append(f"\n[문서 {i}: {result['filename']}]\n{result['chunk']}")
                sources.append({
                    'type': 'document', 
                    'filename': result['filename'],
                    'content': result['chunk'][:100] + '...'
                })
    
    # 웹 검색
    if use_web:
        web_results = web_search(query)
        if web_results and web_results[0]['title'] != '결과 없음':
            context_parts.append("\n\n🌐 **웹 검색 결과:**")
            for result in web_results[:3]:
                context_parts.append(f"\n- {result['title']}: {result['snippet']}")
                sources.append({'type': 'web', 'title': result['title'], 'url': result['url']})
    
    # 프롬프트 구성
    if context_parts:
        full_prompt = f"""다음 정보를 참고하여 질문에 답변해주세요.

{''.join(context_parts)}

---
사용자 질문: {query}

위 정보를 바탕으로 친절하고 정확하게 한국어로 답변해주세요."""
    else:
        full_prompt = query
    
    # Ollama 호출
    system_prompt = "당신은 친절하고 도움이 되는 AI 어시스턴트입니다. 한국어로 답변해주세요."
    response = call_ollama(full_prompt, model=model, system_prompt=system_prompt)
    
    return jsonify({
        'response': response,
        'sources': sources,
        'used_rag': use_rag and bool(all_chunks),
        'used_web': use_web
    })


@app.route('/api/web-search', methods=['POST'])
def api_web_search():
    """웹 검색 API"""
    data = request.json
    query = data.get('query', '')
    
    if not query:
        return jsonify({'error': '검색어가 없습니다'}), 400
    
    results = web_search(query)
    return jsonify({'results': results})


@app.route('/api/ollama/status', methods=['GET'])
def ollama_status():
    """Ollama 연결 상태 확인"""
    try:
        response = requests.get(f'{OLLAMA_HOST}', timeout=5)
        if response.status_code == 200:
            models_response = requests.get(f'{OLLAMA_HOST}/api/tags', timeout=5)
            models = []
            if models_response.status_code == 200:
                models_data = models_response.json()
                models = [m['name'] for m in models_data.get('models', [])]
            
            return jsonify({
                'status': 'connected',
                'host': OLLAMA_HOST,
                'models': models,
                'default_model': DEFAULT_MODEL
            })
    except:
        pass
    
    return jsonify({
        'status': 'disconnected',
        'host': OLLAMA_HOST,
        'models': [],
        'default_model': DEFAULT_MODEL
    })


@app.route('/api/settings', methods=['GET', 'POST'])
def settings():
    """설정 조회/변경"""
    global OLLAMA_HOST, DEFAULT_MODEL
    
    if request.method == 'POST':
        data = request.json
        if 'ollama_host' in data:
            OLLAMA_HOST = data['ollama_host']
        if 'default_model' in data:
            DEFAULT_MODEL = data['default_model']
        
        return jsonify({'success': True})
    
    return jsonify({
        'ollama_host': OLLAMA_HOST,
        'default_model': DEFAULT_MODEL
    })


if __name__ == '__main__':
    print("=" * 50)
    print("🚀 RAG 웹앱 시작! (경량 버전)")
    print(f"📡 Ollama 서버: {OLLAMA_HOST}")
    print(f"🤖 기본 모델: {DEFAULT_MODEL}")
    print("=" * 50)
    print("\n브라우저에서 http://localhost:5001 접속하세요\n")
    
    app.run(host='0.0.0.0', port=5001, debug=True)
